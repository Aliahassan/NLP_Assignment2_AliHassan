
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from PostParser import PostParserRecord
from collections import Counter

## Getting the top-20 frequent tags in LawSE -- There is a reason for passing 21
def get_frequent_tags(post_parser, topk=21):
  lst_tags = []
  for question_id in post_parser.map_questions:
    question = post_parser.map_questions[question_id]
    creation_date_year = int(question.creation_date.split("-")[0])
    tag = question.tags[0]
    lst_tags.append(tag)
  tag_freq_dic = dict(Counter(lst_tags))
  tag_freq_dic = dict(sorted(tag_freq_dic.items(), key=lambda item: item[1], reverse=True))
  return list(tag_freq_dic.keys())[:topk]

# Getting dictionary of train and test samples in form of
# key: tag value: list of tuples in form of (title, body)
def build_train_test(post_parser, lst_frequent_tags):
  dic_training = {}
  dic_test = {}
  for question_id in post_parser.map_questions:
    question = post_parser.map_questions[question_id]
    creation_date_year = int(question.creation_date.split("-")[0])
    tag = question.tags[0]
    if tag in lst_frequent_tags:
      title = question.title
      body = question.body
      if creation_date_year > 2021:
        if tag in dic_test:
          dic_test[tag].append((title, body))
        else:
          dic_test[tag] = [(title, body)]
      else:
        if tag in dic_training:
          dic_training[tag].append((title, body))
        else:
          dic_training[tag] = [(title, body)]
  return dic_test, dic_training

post_parser = PostParserRecord("Posts_law.xml")
lst_frequent_tags = get_frequent_tags(post_parser)
# We removed contract as it had no post after 2021
lst_frequent_tags.remove("contract")
dic_test, dic_training = build_train_test(post_parser, lst_frequent_tags)
# print("class\t#training\t#test")
# for item in dic_training:
#   print(str(item) + "\t" +str(len(dic_training[item]))+"\t"+str(len(dic_test[item])))
print(dic_training)

vectorizer = CountVectorizer()
X_train_counts = vectorizer.fit_transform(dic_training)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB

# Create a pipeline that performs both the CountVectorizer and TfidfTransformer steps
text_clf = Pipeline([('vect', CountVectorizer()),
                     ('tfidf', TfidfTransformer()),
                     ('clf', MultinomialNB())])

# Fit the classifier using the training data
for tag in dic_training:
    X_train = [text[0] + ' ' + text[1] for text in dic_training[tag]]
    y_train = [tag] * len(dic_training[tag])
    text_clf.fit(X_train, y_train)

y_pred = []
y_true = []
for tag in dic_test:
    X_test = [text[0] + ' ' + text[1] for text in dic_test[tag]]
    y_test = [tag] * len(dic_test[tag])
    y_pred += list(text_clf.predict(X_test))
    y_true += y_test

